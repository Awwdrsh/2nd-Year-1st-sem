-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 02, 2026 at 03:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `visitor_sys`
--

-- --------------------------------------------------------

--
-- Table structure for table `Assessment_Users`
--

CREATE TABLE `Assessment_Users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Assessment_Users`
--

INSERT INTO `Assessment_Users` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$p5DLMOcNBtC7zLxaJhcjeurL/Zu0NzPDDrdpmBPI3HhO2FkWG5lvq');

-- --------------------------------------------------------

--
-- Table structure for table `Assessment_Visitors`
--

CREATE TABLE `Assessment_Visitors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `purpose` varchar(255) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `check_in_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `check_out_time` datetime DEFAULT NULL,
  `status` enum('Signed In','Signed Out') DEFAULT 'Signed In'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Assessment_Visitors`
--

INSERT INTO `Assessment_Visitors` (`id`, `name`, `email`, `phone`, `purpose`, `image_path`, `check_in_time`, `check_out_time`, `status`) VALUES
(7, 'John Doe', 'john@gmail.com', '123', 'Meeting', NULL, '2026-02-02 14:10:43', '2026-02-02 19:56:49', 'Signed Out'),
(8, 'Harry', 'harry@gmail.com', '321', 'interview', NULL, '2026-02-02 14:11:10', '2026-02-02 19:56:50', 'Signed Out'),
(9, 'Bro', 'bro@gmail.com', '123', 'meet', NULL, '2026-02-02 14:11:45', '2026-02-02 19:56:48', 'Signed Out');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Assessment_Users`
--
ALTER TABLE `Assessment_Users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `Assessment_Visitors`
--
ALTER TABLE `Assessment_Visitors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Assessment_Users`
--
ALTER TABLE `Assessment_Users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Assessment_Visitors`
--
ALTER TABLE `Assessment_Visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
