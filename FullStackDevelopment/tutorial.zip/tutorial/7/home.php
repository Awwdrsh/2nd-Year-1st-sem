<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Welcome to home page</h1>
    <h2>Welcome user: <?php echo htmlspecialchars($_COOKIE['username']); ?></h2>
    <a href="logout.php">logout</a>
</body>
</html>