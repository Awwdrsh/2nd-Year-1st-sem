<?php
    setcookie("isloggedin", "", time() - 3600);
    unset($_COOKIE['isloggedin']);
    unset($_COOKIE['username']);
    header("Location: index.php");
?>