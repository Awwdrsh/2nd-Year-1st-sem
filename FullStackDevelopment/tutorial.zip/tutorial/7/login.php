<?php
$name = $_POST['username'];
$pass = $_POST['password'];
if($pass === '12345' ){
    setcookie("username", $name);
    setcookie("isloggedin", "true");
    header("Location: home.php");
} else {
    echo "Invalid credentials.";
}

?>