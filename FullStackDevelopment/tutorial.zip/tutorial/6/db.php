
<?php
$server = "mysql:host-localhost;dbname=week6";
$user = "root";
$password = "";
try {
$con = new PDO($server, $user, $password);




// $con->exec("CREATE DATABASE IF NOT EXISTS week6;");
// $con->exec("use week6;");

$con-> exec("CREATE TABLE IF NOT EXISTS student(name varchar(10), id int);");

}catch(PDOExeception $e){
    die("cannot connect to db": . $e-> getMessage);

    
}



?>