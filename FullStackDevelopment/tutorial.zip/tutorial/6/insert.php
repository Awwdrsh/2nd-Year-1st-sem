<?php
	require 'db.php';
	// inserting data into database
	if(isset($_POST['name'])){
		$name = $_POST['name'];
		$age = $_POST['age'];	
	}

	// using prepare statement
	$statement = $con->prepare("INSERT INTO student values(?, ?);");
	$statement->bindValue(1,$name);
	$statement->bindValue(2,$age);
	$statement->execute();

?>


























































