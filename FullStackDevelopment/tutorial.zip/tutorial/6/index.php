
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
  <h1>Php mysql example</h1>
  <form method="POST", action="insert.php">
    <input type="text" name="name", placeholder="Enter your name"><br>
    <input type="number" name="age", placeholder="Enter your age"><br>
    <input type="submit" name="">
  </form>


  <table>
    <thead>
      <th>Name</th>
      <th>Age</th>
    </thead>
    <tbody>
      <?php 
        require 'db.php';
        $data = $con->query("Select *from student;");
        $data = $data->fetchAll(PDO::FETCH_ASSOC);
        foreach($data as $student){
          echo "<tr> <td>{$student['name']}</td><td>{$student['id']}</td></tr>";
        }
      ?>
    </tbody>
  </table>
</body>
</html>